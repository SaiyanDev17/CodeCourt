def handler(event, context):
    return {'statusCode': 200, 'body': 'CodeCourt Lambda Initialized'}